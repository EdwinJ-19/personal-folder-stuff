const fetch = require('node-fetch');
async function data(){
    const getData = await fetch('https://jsonplaceholder.typicode.com/posts');
    getData.json().then(res => console.log(res));
}