const arr = [1,2,4,5,6,8]

// for (let i = 0; i<10; i++){
//     console.log(arr[i]);
// }

// for(const element of arr){
//     console.log(element);
    
// }

const mapArr = arr.map(function(val){
    return val**3;
})

const filterArr = arr.filter(function(val){
    if(val % 2 ==0){
        return false;
    }
    else{
        return true;
    }
})
console.log("mapArr:"+ mapArr);

console.log("filterArr:"+ filterArr);


// fetch api
const fetch = require('node-fetch');
fetch('https://jsonplaceholder.typicode.com/posts')
    .then(response => response.json())
    .then(data => console.log(data))
    .catch(error => console.error('Error:', error));

